# Feedback

I am running into issues with the github cli on mac where it isn't honoring sandbox overries so it can't run the az cli commands
